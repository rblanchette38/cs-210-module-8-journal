#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency; // Map to store items and frequency

public: // read input from a file function
    
    void readInputFromFile(const string& filename) {
        ifstream inputFile(filename);
        if (!inputFile.is_open()) {
            cerr << "unable to open file " << filename << endl;
            return;
        }

        string item;
        while (inputFile >> item) {
            itemFrequency[item]++;
        }

        inputFile.close();
    }

   
    int searchItemFrequency(const string& item) { //search function for frequency
        return itemFrequency[item];
    }

    void printItemFrequencies() { // print function for frequency
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    
    void printHistogram() { //print function for histogram
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

   
    void backupItemFrequencies(const string& filename) {
        ofstream outputFile(filename);
        if (!outputFile.is_open()) {
            cerr << "unable to create backup file " << filename << endl;
            return;
        }

        for (const auto& pair : itemFrequency) {
            outputFile << pair.first << " " << pair.second << endl;
        }

        outputFile.close();
    }
};

int main() {
    ItemTracker tracker;
    tracker.readInputFromFile("CS210_Project_Three_Input_File.txt");

    int choice;
    string item;
    do {
        cout << "Menu:\n";
        cout << "1. Search for an item\n";
        cout << "2. list of items with frequency\n";
        cout << "3. Print  histogram with item frequency\n";
        cout << "4. Exit the program\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter item to search for: ";
            cin >> item;
            cout << "Frequency of " << item << ": " << tracker.searchItemFrequency(item) << endl;
            break;
        case 2:
            tracker.printItemFrequencies();
            break;
        case 3:
            tracker.printHistogram();
            break;
        case 4:
            tracker.backupItemFrequencies("frequency.dat");
            cout << "Exit.\n";
            break;
        default:
            cout << "enter a number\n";
        }
    } while (choice != 4);

    return 0;
}